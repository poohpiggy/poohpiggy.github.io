﻿# 游戏的脚本可置于此文件中。

# 声明此游戏使用的角色。颜色参数可使角色姓名着色。
init python:
    renpy.music.register_channel("music")
    renpy.music.register_channel("stare")

define bing = Character("冰冰")
define me = Character("我")
define xt = Character("Server")
define NOBODY = Character("???")
define people = Character("众人")
define qx = Character("qiexin")  # 烤鱼大王
define wsyaba = Character("wsyaba")
define mtm = Character("mtm")

# 游戏在此开始。

label chap2:
    play music "audio/BGM.mp3" volume 0.05
    "提示，一二章节之间并无明显衔接，可能是虚构史学家所作"
    "但是你得受着，这是大受着时代"
    hide main_menu at center with dissolve
    image bg_spawn = "bg/mc_spawn_plaza.png"  # 出生点广场
    image bg_river = "bg/mc_river_bank.png"  # 河流岸边（钓鱼场景）
    image bg_taiga = "bg/mc_taiga_camp.png"  # 针叶林营地（烤鱼场景）
    image bg_village = "bg/mc_village_square.png"  # 村庄广场（集体活动场景）
    
    image qx_default = "sprite/qx_holding_rod.png"  # qiexin持附魔鱼竿
    image qx_cooking = "sprite/qx_by_campfire.png"  # qiexin篝火烤鱼
    image qx_storing = "sprite/qx_chest.png"  # qiexin整理鱼箱
    image bing_admin = "sprite/bing_with_op.png"  # 冰冰持管理员杖
    image wsyaba_redstone = "sprite/wsyaba_holding_dust.png"  # wsyaba持红石粉
    image wsyaba_machine = "sprite/wsyaba_with_machine.png"  # wsyaba调试红石机
    image mtm_girl = "sprite/mtm_holding_flower.png"  # mtm持向日葵
    image mtm_organizing = "sprite/mtm_organizing_fish.png"  # mtm整理生鱼
    image me_default = "sprite/me_with_sword.png"  # 新人持铁剑

# 原版MC物品图像
    image item_raw_cod = "item/mc_raw_cod.png"  # 生鳕鱼
    image item_cooked_cod = "item/mc_cooked_cod.png"  # 熟鳕鱼
    image item_raw_salmon = "item/mc_raw_salmon.png"  # 生鲑鱼
    image item_cooked_salmon = "item/mc_cooked_salmon.png"  # 熟鲑鱼
    image item_ench_rod = "item/mc_enchanted_fishing_rod.png"  # 附魔钓鱼竿
    image item_double_chest = "item/mc_double_chest.gif"  # 大箱子

    show bg_spawn with fade  # 初始场景：出生点广场
    play sound "audio/fire.ogg" fadein 1.0  # 篝火声渐入
    show bing_admin at left with pixellate  # 服主冰冰登场
    bing "服务器今天新来了几位玩家，我得去出生点接一下，顺便提醒他们注意安全。"
    
    show me_default at center with pixellate  # 新人登场
    me "请问这里是【WTUMC】服务器吗？我是刚加入的玩家。"
    bing "对！我是服主冰冰，有任何问题都可以在聊天频道喊我。"
    bing "你看那边针叶林方向的篝火——"
    show bg_taiga at center with dissolve
    show qiexin walking at center
    bing "那是qiexin，我们都叫他“烤鱼大王”，要是你饿了，找他要熟鱼准没错。"
    
    me "烤鱼大王？是他烤鱼特别厉害吗？"
    play sound "audio/click.ogg" fadein 0.5  # 聊天提示声
    hide bing_admin
    show wsyaba_redstone at right with pixellate  # wsyaba登场
    wsyaba "（从聊天频道切到现场）不止厉害，关键是他烤的鱼数量，全服第一。"
    wsyaba "我上周帮他装红石自动分类箱，光熟鳕鱼就装了4个大箱子，还没算熟鲑鱼。"
    
    me "这么多？！他为什么烤这么多鱼啊？"
    bing "qiexin就喜欢钓鱼，钓多了吃不完就烤了存着，之前服务器缺食物，他一次捐了5组熟鱼。"
    bing "走，我带你去见他，顺便介绍mtm给你认识，她经常帮qiexin整理生鱼。"
    hide wsyaba_redstone with dissolve
    hide qiexin walking
    hide bing_admin me_default wsyaba_redstone with dissolve
    hide bg_taiga 
    hide bg_spawn 
    hide me_default with pixellate
    play sound "audio/fire.ogg" volume 0.8  # 篝火声清晰化
    show qx_cooking at center with dissolve  # qiexin烤鱼形象
    show mtm_organizing at left with pixellate  # mtm整理生鱼
    mtm "（分拣生鱼）qiexin，这波生鲑鱼有32条，够你烤一会了。"
    qx "（翻动篝火上的鱼）刚好，刚才钓鱼竿又钓了组生鳕鱼，等下一起烤了。"
    hide qx_cooking
    show item_ench_rod at truecenter
    mtm "哇，你的附魔鱼竿也太好用了，我钓半天都钓不到10条。"
    hide item_ench_rod with pixellate
    show bing_admin at right with pixellate
    bing "qiexin，mtm，我带新人来了。"
    show bing_admin at right with moveoutright
    hide mtm_organizing
    show qx_cooking at left
    qx "（抬头）新人啊！快坐，篝火边暖和，我这波熟鲑鱼马上好。"
    hide mtm_organizing
    show qiexin walking at left 
    show item_cooked_salmon at truecenter with dissolve
    qx "刚烤好的熟鲑鱼，恢复饱食度很顶，你先拿着。"
    play sound "audio/mc_eat_food.mp3" fadein 0.5  # 进食声
    xt "饱食度+6"
    me "谢谢！这熟鲑鱼比我自己烤的香多了...qiexin，大家为什么叫你烤鱼大王啊？"
    mtm "（笑着放下生鱼）因为他每天除了钓鱼就是烤鱼，服务器没人比他烤得多！"
    show qx_storing with dissolve
    mtm "上次冰冰统计全服食物存量，他的熟鱼加起来比所有玩家的面包总量还多。"
    qx "（挠头）其实就是喜欢钓鱼，烤了存箱子里方便，大家开玩笑叫的。"
    qx "有次新人没食物，我直接分了2组给他们。"
    me "太厉害了！我以后也想钓这么多鱼，可惜我只有普通鱼竿。"
    hide item_cooked_salmon
    hide item_raw_cod
    play sound "audio/mc_redstone_click.mp3" fadein 0.5  # 红石机械声
    hide item_double_chest
    hide me_default
    hide qiexin walking
    hide qx_storing
    hide bing_admin with dissolve
    show wsyaba_machine at truecenter with moveinright # wsyaba带红石机登场
    hide mtm_organizing
    wsyaba "（推着红石机）qiexin，我给你改的自动烤鱼机好了，一次能烤8条鱼。"
    hide wsyaba_machine
    show wsyaba_redstone with dissolve
    wsyaba "以后你不用守着篝火烤了，放好生鱼，机器自动烤好送进箱子。"
    
    menu:  # 剧情分支：集体钓鱼/村庄分享
        "组织集体钓鱼，帮qiexin多钓生鱼":
            bing "正好今天服务器人多，不如组织个集体钓鱼活动，帮qiexin多囤点生鱼。"
            mtm "好啊！我去通知其他玩家，让大家带好鱼竿到河边集合。"
            qx "那我去准备备用鱼竿，给没鱼竿的新人用。"
            jump group_fishing
        
        "去村庄广场，分享qiexin的熟鱼给村民":
            me "我听说附近有个村庄，不如我们带点熟鱼去分享给村民吧？"
            bing "这个主意好！还能和村民换绿宝石，一举两得。"
            wsyaba "我把自动烤鱼机带上，路上要是生鱼不够，还能随时烤。"
            jump village_share

# 分支1：组织集体钓鱼活动
label group_fishing:
    show bg_river with fade  # 切换场景：河流岸边
    play sound "audio/swim6.ogg" loop volume 0.7  # 钓鱼声循环
    show qx_default at center with dissolve
    qx "（挥动画竿）大家听好，钓鱼要等浮标完全下沉再拉，不然容易脱钩！"
    show me_default at right with pixellate
    me "（尝试挥竿）浮标动了！现在拉吗？"
    qx "等1秒！对，就是现在！"
    play sound "audio/swim6.ogg" # 成功上钩音效
    xt "经验+5"
    
    show mtm_girl at left with pixellate
    mtm "（举着生鲑鱼）qiexin，我钓到生鲑鱼了！比生鳕鱼恢复的饱食度高吧？"
    qx "对，熟鲑鱼能恢复6点饱食度，等下优先烤这个。"
    hide me_default
    show bing_admin at right with pixellate
    bing "（统计人数）目前来了12个玩家，每人钓10条鱼，就能凑120条生鱼了。"

    play sound "audio/levelup.ogg" fadein 0.5  # 等级提升声
    xt "集体钓鱼活动完成！共钓到【生鳕鱼】x78，【生鲑鱼】x42，【生河豚】x5"
    mtm "（整理生鱼）太好了！这么多生鱼，够qiexin烤好几天了。"
    bing "我已经通知大家，明天在村庄广场办烤鱼宴，用今天钓的鱼当食材。"
    qx "没问题！今晚我就把这些生鱼烤一半，明天带过去。"
    hide all with dissolve
    jump fishing_ending

# 分支2：村庄广场分享熟鱼
label village_share:
    show bg_village with fade  # 切换场景：村庄广场
    play sound "audio/fire.ogg" volume 0.6  # 篝火声背景
    show qx_cooking at center with dissolve
    qx "（烤着鱼）村民好像很喜欢熟鱼，刚才已经用2条熟鳕鱼换了1个绿宝石。"
    show mtm_organizing at left with pixellate
    mtm "（清点熟鱼）我们带了3组熟鳕鱼和2组熟鲑鱼，应该够和全村村民换了。"
    hide qx_cooking
    hide mtm_organizing with pixellate
    "与此同时，另外一边......"
    show bing_admin at center with pixellate
    play sound "audio/yes2.ogg"
    bing "（和村民对话）村民说想要更多熟鱼，他们愿意用小麦和胡萝卜换。"
    play sound "audio/yes2.ogg"
    me "（帮着递鱼）qiexin，熟鱼快不够了，要不要用自动烤鱼机烤点？"
    hide bing_admin
    show wsyaba_machine at truecenter with dissolve
    wsyaba "早准备好了！我这就把剩下的生鱼放进去，5分钟就能烤好。"
    
    play sound "audio/mc_chest_open.mp3" fadein 0.5  # 箱子开关声
    wsyaba "（打开机器储物箱）搞定！新烤了32条熟鳕鱼，够换了。"
    hide wsyaba_machine
    show qiexin walking
    qx "伙计，你把这些熟鱼拿给村民，换点小麦回来，以后还能做面包。"
    me "好！我这就去。"
    show me_default with dissolve
    play sound "audio/levelup.ogg" fadein 0.5  # 等级提升声
    xt "村庄分享活动完成！获得【绿宝石】x12，【小麦】x64，【胡萝卜】x32"
    bing "太好了！这些物资够服务器用一阵了，多亏了qiexin的熟鱼。"
    mtm "以后可以常来村庄换物资，qiexin的熟鱼就是最好的交换品。"
    qx "只要大家需要，我随时可以烤更多鱼。"
    "烤鱼宴结束了，接下来你决定"
    label fenzhi1:
        menu:
            "和大家一起回基地":
                jump huijia
            "留下来收拾摊子":
                jump shoushi

    hide all with dissolve
    jump village_ending

label huijia:
    "😋味真足"
    "但是你们留下的火好像给村庄搞着了"
    show died at truecenter
    "BE 着了，毁了"
    menu:
        "回到上一个分支":
            jump fenzhi1
        "标题页面":
            return

# 结局1：集体钓鱼活动结局
label fishing_ending:
    show bg_village with fade  # 场景：村庄广场（烤鱼宴）
    play sound "audio/fire.ogg" volume 0.7  # 篝火声温暖
    show bing walking at truecenter with dissolve
    bing "（举起熟鲑鱼）欢迎大家来参加烤鱼宴！感谢qiexin提供的120条熟鱼！"
    play sound "audio/mc_eat_food.mp3" fadein 0.5  # 众人进食声
    hide bing walking
    show me_default
    me "（吃着熟鱼）qiexin，你的熟鱼太好吃了，以后我也要学钓鱼。"
    hide me_default
    show wsyaba
    wsyaba "（拍着自动烤鱼机）我已经把自动烤鱼机送给qiexin了，以后他烤的鱼会更多。"
    hide wsyaba
    show mtm at truecenter
    show item_double_chest at truecenter with dissolve
    mtm "我帮qiexin整理了新的鱼箱，现在他有10个大箱子存熟鱼了。"
    play sound "audio/levelup.ogg" fadein 0.5  # 等级提升声
    xt "服务器解锁集体活动【每周烤鱼宴】，qiexin获得称号“烤鱼大王（官方认证）”"
    show qiexin walking
    qx "（笑着挠头）谢谢大家，以后每周我都会准备足够的熟鱼，让大家吃个够。"
    hide qiexin walking
    show bing walking
    bing "这是服务器给你的奖励【附魔钓鱼竿（时运32767）】，祝你钓更多鱼。"
    hide bing walking
    show item_ench_rod at truecenter with dissolve

    scene black with fade  # 黑屏结局
    "HE 烤鱼大王" 
    menu:
        "继续下一章":
            jump zhang3
        "标题页面":
            return

label village_ending:
    "大家似乎都走了"
    "但是留下的火好像给村子点着了"
    "很庆幸你留了下来"
    show steve walking at truecenter with pixellate
    me "但是钩子村民好像烧死了"
    me "再也没有人买卖钩子了"
    me ":("
    "但是你拯救了大部分的村子"
    "让大部分村民活了下来"
    "你是真正的整活大王"
    "HE 村子有点死，但是你整活了"
    menu:
        "继续下一章":
            jump zhang3
        "标题页面":
            return
    # 此处为游戏结尾。

    return