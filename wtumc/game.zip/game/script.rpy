﻿# 起始文件/目录

init python:
    renpy.music.register_channel("music")
    renpy.music.register_channel("stare")

define bing = Character("冰冰")
define me = Character("我")
define xt = Character("Server")
define NOBODY = Character("???")
define people = Character("众人")
define qx = Character("qiexin")  # 烤鱼大王
define wsyaba = Character("wsyaba")
define mtm = Character("mtm")

# 游戏在此开始。

label start:
    show main_menu at center
    "这是WTUMC的同人小游戏"
    "不爱看就憋着（"
    "❤来自pig"
    "下面是章节目录"
    menu:
        "第一章 招新":
            jump chap1
        "第二章 烤鱼大王qiexin":
            jump chap2
        