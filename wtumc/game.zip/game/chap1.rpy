﻿# 游戏的脚本可置于此文件中。

# 声明此游戏使用的角色。颜色参数可使角色姓名着色。
init python:
    renpy.music.register_channel("music")
    renpy.music.register_channel("stare")

define bing = Character("冰冰")
define me = Character("我")
define xt = Character("Server")
define NOBODY = Character("???")
define people = Character("众人")
define qx = Character("qiexin")  # 烤鱼大王
define wsyaba = Character("wsyaba")
define mtm = Character("mtm")

# 游戏在此开始。

label chap1:
    hide main_menu at center
    stop music fadeout 2.0
    play music "audio/BGM.mp3" volume 0.05

    me "头好晕。"
    me "不是在纺专吗"

    show fangzhuan with dissolve
    me "(回想起了刚刚学校的画面)"

    me "刚刚好像遇到了个方块入"
    hide fangzhuan with fade
    show bing walking at center with pixellate
    me "嚷着什么要玩一辈子安慕希，然后我就晕了"

    hide bing walking with pixellate
    me "算了，我还是个大学生"
 
    me "这些问题还是交给睡醒后的我吧"
    me "(于是你两眼一黑又睡了过去)"
    $ renpy.music.set_pause(True, channel="music")

    me "zzz"
    me "zzzz"
    me "zzzzz"
    show bg room with fade

    $ renpy.music.set_pause(False, channel="music")
    play sound "audio/click.ogg"
    show steve walking at center with pixellate
    xt "玩家Steve加入了游戏"
    me "给我干哪儿来了，这还是武纺吗"

    hide steve walking
    play sound "audio/click.ogg"
    xt "玩家Sakura_Estelle加入了游戏"
    play sound "audio/stone.ogg"
    bing "我听到了「小登」的回响"
    play sound "audio/idle2.ogg"
    show bing walking at center with moveinright

    play sound "audio/hit4.ogg"
    bing "眼睛袅袅了"
    bing "哦哦哦哦哦齁齁齁齁是小登"
    play sound "audio/yes2.ogg"
    bing "终于被我拐来了吗"
    play sound "audio/idle2.ogg"
    bing "我要大调查你"

    hide bing walking with pixellate
    hide bg room with fade
    $ renpy.music.set_pause(True, channel="music")
    me "为什么，我的脑子又开始疼起来了"
    play sound "audio/portal2.ogg"
    show psc at center with vpunch
    me "这些"
    play stare "audio/stare.ogg"
    show psc1 at center with vpunch
    me "都是什么"
    play sound "audio/portal.ogg"
    show psc2 at center with vpunch
    me "我的记忆出现问题了吗"
    play sound "audio/scream4.ogg"
    show psc3 at center with vpunch
    me "还是？"
    play sound "audio/portal2.ogg"
    show psc4 at center with vpunch
    me "还是梦吗"

    hide psc
    hide psc1
    hide psc2
    hide psc3
    hide psc4
    show qiexin walking at center with pixellate
    NOBODY "{color=#de2626}听我说{/color}"
    play sound "audio/yes2.ogg"
    NOBODY "{color=#de2626}「你是一只卡拉彼丘量产猫娘」{/color}"
    play sound "audio/yes2.ogg"
    NOBODY "跟我一起说：{color=#de2626}「喵拉彼丘喵啦喵」{/color}"
    play sound "audio/yes2.ogg"
    me "不"
    me "不！！！"
    me "我是"
    me "我是？"
    NOBODY "{color=#ff0000}锘挎槬鐪犱笉瑙夋檽锛屽澶勯椈鍟奸笩锘挎槬鐪犱笉瑙夋檽锛屽澶勯椈鍟奸笩{/color}"
    $ renpy.music.set_pause(True, channel="stare")

    hide qiexin walking
    play sound "audio/fire_hurt3.ogg"
    me "啊啊啊啊啊啊啊啊啊啊"
    play sound "audio/fire_hurt3.ogg"
    show qinshi at center with zoomin
    me "原来是梦么"
    me "第一天住寝睡床上果然不大舒服，还是得适应"
    me "你🏠的宿舍还是太权威了（"
    me "（如是吐槽着，你简单洗漱，开始了愉快的周末生活）"
    me "（正巧这是军训完第一个周末，时间充裕）"
    me "（听说会有百团大战？先去实地考察考察）"
    hide qinshi with dissolve
    $ renpy.music.set_pause(False, channel="music")
    show dayshitang at center with dissolve
    me "诶诶已经有摊子开始搭了吗"
    me "牛魔"
    NOBODY "不可以牛魔喵"
    me "（？？？）"
    me "（虽然惊讶于你自己莫名其妙多出来用于吐槽的口癖）"
    me "（还有奇怪的回音）"
    me "（但你还是向前走去）"

    hide dayshitang with dissolve
    show dayshitangce at center with dissolve
    me "这边好像就走到头了"
    me "搞点早午饭，然后回寝室吧"
    hide dayshitangce with dissolve
    show food at center with dissolve
    me "味真足"
    "吃完饭后，向寝室走去，你决定"
    label reborn1:
        hide died
        show food at center
        menu:
            "回寝室睡觉":
                jump daysleep
            "回寝室打三角洲":
                jump deltaforce

label deltaforce:
    hide food with dissolve
    "你选择了回寝室打三角洲！"
    show df1 at center  with dissolve
    me "牛魔，谁做的游戏"
    $ renpy.music.set_pause(True, channel="music")
    show df at center with dissolve
    me "寄"
    hide df1 with dissolve
    $ renpy.movie_cutscene("images/joker.webm")
    hide df with dissolve
    me "为什么我的鼻子红红的"
    play sound "audio/hurt.mp3"
    "你怒火攻心"
    "一气之下"
    "气死了"
    stop sound fadeout 2.0
    show died at center with pixellate
    "BE 珍爱生命 远离三角洲"
    menu:
        "重生":
            jump reborn1
        "标题界面":
            return

label daysleep:
    hide food with dissolve
    "你选择了回寝室睡觉！"
    $ renpy.music.set_pause(True, channel="music")
    show qinshi at center with zoomin
    me "zzz"
    me "zzz"
    hide qinshi with zoomout
    me "zzzzz"
    show qinshinight at center with zoomin
    $ renpy.music.set_pause(False, channel="music")
    me "坏了，早午饭吃完疑似晕碳睡过头了"
    me "这才几月份啊 7点钟就这么黑了"
    me "还是先出去转转吧"

    hide qinshinight with dissolve
    show nightshitang with dissolve
    me "我草，真的有“百团大战”，学长诚不欺我"
    me "欸那是什么"
    me "你的目光向远处扫去，一种异样但又{color=#ffffb5}熟悉{/color}的感觉浮现"
    $ renpy.music.set_pause(True, channel="music")
    $ renpy.movie_cutscene("images/zhaoxin.webm")
    me "那几个人手里拿着平板，好像在搞什么社团招新"

    "你决定"
    label reborn2:
        hide qinshinight
        menu:
            "回寝室睡觉":
                jump nightsleep
            "上前看看":
                jump lookzhaoxin

label nightsleep:
    hide nightshitang with zoomout
    "你选择了回寝室睡觉！"
    show qinshinight at center with zoomin
    "（是啊，你只是一个眼神清澈的大学生）"
    "（窗外发生的事情似乎与你无关）"
    "（你与WTU方块学园成为了两条平行线，不再相交）"
    "BE 懒狗别睡了"
    menu:
        "回到上一个分支":
            jump reborn2
        "标题界面":
            return

label lookzhaoxin:
    $ renpy.music.set_pause(False, channel="music")
    "你选择了上前看看"
    "招新的队伍里有几个略显青涩的身影"

    me "已经忽悠到小登了吗，有点意思"
    hide nightshitang with pixellate
    show zhaoxin1 with pixellate
    me "好看欸，这是安慕希吗？"
    show bing walking at center with pixellate
    NOBODY "是的是的"
    hide bing walking
    show qiexin walking at center
    NOBODY "是的是的"
    hide qiexin walking
    show pig walking at center
    NOBODY "是的是的"
    hide pig walking
    show keqing walking at center
    NOBODY "是的是的"
    hide keqing walking
    me "大伙好像有点太热情了"
    me "刚好我也玩MC（"
    show bing walking at center with moveinright
    NOBODY "那就加个群吧，大家都玩MC的"
    "他向我展示了一个二维码"
    show qrcode at truecenter with dissolve
    NOBODY "再给你个钥匙扣"
    hide qrcode with dissolve
    show apple at truecenter with dissolve
    "意识到WTUMCer的热情，你决定"
    menu:
        "加入他们":
            jump jiaru
        "回答：“啊我以为MN世界呢，打扰了（”":
            jump mnsj

label mnsj:
    $ renpy.music.set_pause(True, channel="music")
    hide apple
    hide bing walking
    hide zhaoxin1
    show nightshitang
    play stare "audio/stare.ogg"
    show bing walking at center with pixellate
    NOBODY "？"
    hide bing walking
    show qiexin walking at center
    NOBODY "？"
    hide qiexin walking
    show pig walking at center
    NOBODY "？"
    hide pig walking
    show keqing walking at center
    NOBODY "？"
    "面对众人的不解，你决定"
    menu:
        "回答：啊哈哈其实我开玩笑的":
            hide keqing walking
            people "哦哦那就行"
            jump jiaru
        "回答：“？”":
            hide keqing walking
            hide nightshitang
            jump meile

label meile:
    "你被冰冰大调查注入MC基因了"
    "你决定"
    menu:
        "成为WTUMCer":
            jump jiaru
        "我还是要玩____":
            "这我真没话说了"
            "BE 忠实的卫道士"
            menu:
                "回到上一个分支":
                    $ renpy.music.set_pause(True, channel="stare")
                    jump meile
                "标题页面":
                    return

label jiaru:
    hide apple
    hide bing walking
    show bing walking at center
    $ renpy.music.set_pause(True, channel="stare")
    NOBODY "豪德"
    NOBODY "之后你就是WTM方块学园的一员了喵"
    xt "*这使你充满了决心"
    me "（？？）"
    me "（又是不知道哪里出来的话，不过今天倒是很充实）"
    hide bing walking
    "你拿上了钥匙扣，边刷着手机上的群消息，边向寝室方向走去"
    "从此你就跟WTUMC过上了没羞没臊的生活"
    "吗？"
    menu:
        "继续下一章":
            jump zhang2
        "标题页面":
            return